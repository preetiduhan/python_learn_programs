to create a new package

 python setup.py sdist

to Upload

 python -m twine upload dist/*

